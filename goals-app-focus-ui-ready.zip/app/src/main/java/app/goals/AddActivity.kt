package app.goals

import android.app.Activity
import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class AddActivity : Activity() {
    private var kind = 0
    private var date = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.load(this)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val pal = PalGen.get(this, 85)
        val m = Model(this)
        date = Store.sel(this)
        val goals = m.goals.filter { !it.long }
        val lists = m.lists
        fun dp(v: Int): Int = Ui.dp(this, v)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = Lang.dir
        root.setPadding(dp(20), dp(18), dp(20), dp(16))

        val title = EditText(this)
        title.hint = T("ماذا تريد أن تنجز؟", "What do you want to get done?")
        title.textSize = 22f
        title.setTextColor(pal.fg)
        title.setHintTextColor(pal.muted)
        title.setBackgroundColor(Color.TRANSPARENT)
        title.setSingleLine(true)
        title.setPadding(0, dp(4), 0, dp(4))
        root.addView(title, Ui.lp(Ui.MP, Ui.WC))

        val desc = EditText(this)
        desc.hint = T("وصف", "Description")
        desc.textSize = 14f
        desc.setTextColor(pal.fg)
        desc.setHintTextColor(pal.muted)
        desc.setBackgroundColor(Color.TRANSPARENT)
        desc.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        desc.minLines = 2
        desc.setPadding(0, dp(4), 0, dp(10))
        desc.gravity = Gravity.TOP or Gravity.START
        root.addView(desc, Ui.lp(Ui.MP, Ui.WC))

        val kindRow = LinearLayout(this)
        kindRow.orientation = LinearLayout.HORIZONTAL
        root.addView(kindRow, Ui.lp(Ui.MP, Ui.WC, dp(4)))

        fun tint(items: List<String>): ArrayAdapter<String> = object : ArrayAdapter<String>(this@AddActivity, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.setTextColor(pal.fg)
                v.textSize = 15f
                return v
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getDropDownView(position, convertView, parent) as TextView
                v.setTextColor(Color.WHITE)
                return v
            }
        }

        val spGoal = Spinner(this)
        val goalNames = ArrayList<String>()
        for (g in goals) goalNames.add(g.title)
        if (goalNames.isEmpty()) goalNames.add(T("لا توجد أهداف، أضف هدفًا من التطبيق", "No goals yet — add one in the app"))
        val ga = tint(goalNames)
        ga.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spGoal.adapter = ga
        root.addView(spGoal, Ui.lp(Ui.MP, Ui.WC, dp(6)))

        val spList = Spinner(this)
        val listNames = ArrayList<String>()
        for (l in lists) listNames.add(l.title)
        listNames.add(T("+ قائمة جديدة", "+ New list"))
        val la = tint(listNames)
        la.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spList.adapter = la
        root.addView(spList, Ui.lp(Ui.MP, Ui.WC, dp(6)))

        val newList = EditText(this)
        newList.hint = T("اسم القائمة", "List name")
        newList.setTextColor(pal.fg)
        newList.setHintTextColor(pal.muted)
        newList.setSingleLine(true)
        root.addView(newList, Ui.lp(Ui.MP, Ui.WC))

        val dateChip = Ui.chip(this, "", pal, true)
        fun dateLabel(): String {
            if (date == todayDay()) return T("اليوم", "Today")
            val c = civil(date)
            return c[2].toString() + " " + MONTHS[c[1] - 1]
        }
        dateChip.text = dateLabel()
        dateChip.setOnClickListener {
            val c = civil(date)
            DatePickerDialog(this, DatePickerDialog.OnDateSetListener { _, y, mo, dd ->
                date = ymd(y, mo + 1, dd)
                dateChip.text = dateLabel()
            }, c[0], c[1] - 1, c[2]).show()
        }
        val dateRow = LinearLayout(this)
        dateRow.orientation = LinearLayout.HORIZONTAL
        dateRow.addView(dateChip, Ui.lp(Ui.WC, Ui.WC))
        // مكافأة Focus: رصيد يُمنح عند إنجاز المهمة (اختياري)
        val rwEt = EditText(this)
        rwEt.setSingleLine(true)
        rwEt.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        rwEt.hint = T("+ مكافأة", "+ Reward")
        rwEt.textSize = 14f
        rwEt.setTextColor(pal.fg)
        rwEt.setHintTextColor(pal.muted)
        rwEt.background = Ui.shape(PalGen.alpha(pal.fg, 18), 0, dp(16).toFloat())
        rwEt.setPadding(dp(14), dp(8), dp(14), dp(8))
        val lpr = LinearLayout.LayoutParams(dp(110), Ui.WC)
        lpr.marginStart = dp(8)
        dateRow.addView(rwEt, lpr)
        root.addView(dateRow, Ui.lp(Ui.MP, Ui.WC, dp(10)))

        val kinds = ArrayList<TextView>()
        fun refreshUi() {
            for (i in kinds.indices) {
                val on = i == kind
                kinds[i].setTextColor(if (on) pal.accent else pal.muted)
                kinds[i].background = Ui.shape(if (on) PalGen.alpha(pal.accent, 45) else Color.TRANSPARENT, pal.line, dp(18).toFloat(), 1)
            }
            spGoal.visibility = if (kind == 1) View.VISIBLE else View.GONE
            spList.visibility = if (kind == 2) View.VISIBLE else View.GONE
            newList.visibility = if (kind == 2 && spList.selectedItemPosition == lists.size) View.VISIBLE else View.GONE
            dateRow.visibility = if (kind == 2) View.GONE else View.VISIBLE
            desc.visibility = if (kind == 2) View.GONE else View.VISIBLE
        }
        val names = arrayOf(T("عادية", "Task"), T("ضمن هدف", "In a goal"), T("في قائمة", "In a list"))
        for (i in names.indices) {
            val chip = Ui.chip(this, names[i], pal, false)
            chip.setOnClickListener {
                kind = i
                refreshUi()
            }
            kinds.add(chip)
            val lp = LinearLayout.LayoutParams(Ui.WC, Ui.WC)
            lp.setMargins(0, 0, dp(8), 0)
            kindRow.addView(chip, lp)
        }
        spList.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                refreshUi()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        refreshUi()

        val save = Ui.btn(this, T("إضافة", "Add"), pal.accent, if (pal.dark) Color.parseColor("#0B1020") else Color.WHITE)
        val cancel = Ui.btn(this, T("إلغاء", "Cancel"), Color.TRANSPARENT, pal.muted)
        cancel.setOnClickListener { finish() }
        save.setOnClickListener {
            val t = title.text.toString().trim()
            val ds = desc.text.toString().trim()
            if (t.isEmpty()) {
                Toast.makeText(this, T("اكتب المهمة أولًا", "Type a task first"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            when (kind) {
                0 -> Store.addLoose(this, t, dateStr(date), ds, parseNum(rwEt.text.toString()) ?: 0.0)
                1 -> {
                    if (goals.isEmpty()) {
                        Toast.makeText(this, T("لا توجد أهداف، أضف هدفًا من التطبيق", "No goals yet — add one in the app"), Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    val g = goals[spGoal.selectedItemPosition]
                    val dd = minOf(maxOf(date, g.s), g.e)
                    if (dd != date) Toast.makeText(this, T("تم ضبط اليوم داخل مدى الهدف", "Date moved inside the goal range"), Toast.LENGTH_SHORT).show()
                    Store.addGoalTask(this, g.id, t, dateStr(dd), ds, parseNum(rwEt.text.toString()) ?: 0.0)
                }
                else -> {
                    val pos = spList.selectedItemPosition
                    val lid: String
                    if (pos >= lists.size) {
                        val nm = newList.text.toString().trim()
                        if (nm.isEmpty()) {
                            Toast.makeText(this, T("اكتب اسم القائمة", "Type a list name"), Toast.LENGTH_SHORT).show()
                            return@setOnClickListener
                        }
                        lid = Store.addList(this, nm)
                    } else lid = lists[pos].id
                    Store.addListItem(this, lid, t)
                }
            }
            Store.setView(this, 0)
            if (kind == 2) Store.setFlag(this, "showLists", true)
            GoalsWidget.refresh(this)
            finish()
        }
        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        btns.addView(save, LinearLayout.LayoutParams(0, Ui.WC, 2f))
        btns.addView(cancel, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        root.addView(btns, Ui.lp(Ui.MP, Ui.WC, dp(14)))

        setContentView(root)
        Glass.apply(this, pal)
        window.setGravity(Gravity.TOP)
        val lp = window.attributes
        lp.y = dp(40)
        window.attributes = lp
    }
}
