package app.goals

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.widget.LinearLayout

class MenuActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.load(this)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val pal = PalGen.get(this, 85)
        fun dp(v: Int): Int = Ui.dp(this, v)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = Lang.dir
        root.setPadding(dp(6), dp(6), dp(6), dp(6))
        fun item(t: String, on: Boolean? = null, f: () -> Unit) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(11), dp(14), dp(11))
            row.addView(Ui.tv(this, t, 14f, pal.fg), LinearLayout.LayoutParams(0, Ui.WC, 1f))
            if (on != null) row.addView(Ui.tv(this, if (on) "●" else "○", 11f, if (on) pal.accent else pal.muted))
            row.setOnClickListener {
                f()
                GoalsWidget.refresh(this)
                finish()
            }
            root.addView(row, Ui.lp(Ui.MP, Ui.WC))
        }
        val showDone = Store.opt(this, "showDone", false)
        val details = Store.opt(this, "details", false)
        val lists = Store.opt(this, "showLists", false) || Store.view(this) == 2
        item(T("إظهار المهام المنجزة", "Show completed"), showDone) { Store.setFlag(this, "showDone", !showDone) }
        item(T("إظهار التفاصيل", "Show details"), details) { Store.setFlag(this, "details", !details) }
        item(T("عرض القوائم", "Show lists"), lists) {
            Store.setFlag(this, "showLists", !lists)
            if (Store.view(this) == 2) Store.setView(this, 0)
        }
        item(if (Lang.en) "العربية" else "English") { Store.setLang(this, if (Lang.en) "ar" else "en") }
        item("Focus") { startActivity(Intent(this, FocusActivity::class.java).putExtra("from", "menu")) }
        item(T("الإعدادات", "Settings")) { startActivity(Intent(this, SettingsActivity::class.java)) }
        item(T("فتح التطبيق", "Open app")) { startActivity(Intent(this, MainActivity::class.java)) }
        setContentView(root)
        Glass.apply(this, pal, 0.6f)
        window.setGravity(Gravity.TOP or (if (Lang.en) Gravity.LEFT else Gravity.RIGHT))
        window.setDimAmount(0.12f)
        val lp = window.attributes
        lp.x = dp(14)
        lp.y = dp(70)
        window.attributes = lp
    }
}
