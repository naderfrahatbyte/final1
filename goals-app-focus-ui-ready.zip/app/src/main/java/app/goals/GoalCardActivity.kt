package app.goals

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.LinearLayout

class GoalCardActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.load(this)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val pal = PalGen.get(this, 85)
        val m = Model(this)
        val ws = wsOf(Store.sel(this))
        fun dp(v: Int): Int = Ui.dp(this, v)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = Lang.dir
        root.setPadding(dp(20), dp(18), dp(20), dp(16))

        val vis = m.goals.filter { it.e - ws >= 0 && it.s - ws <= 6 }.sortedBy { if (it.long) 0 else 1 }
        if (vis.isEmpty()) {
            root.addView(Ui.tv(this, T("لا أهداف في هذا الأسبوع", "No goals this week"), 16f, pal.muted))
        }
        for (g in vis) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val inset = if (g.parent.isNotEmpty() && m.byId[g.parent] != null) dp(18) else 0
            row.setPadding(inset, dp(8), 0, dp(8))
            val dot = View(this)
            dot.background = Ui.shape(PalGen.goalColor(m, pal, g), 0, dp(6).toFloat())
            row.addView(dot, LinearLayout.LayoutParams(dp(12), dp(12)))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dp(12), 0, dp(12), 0)
            col.addView(Ui.tv(this, g.title, 16f, pal.fg, true))
            val a = civil(g.s)
            val b = civil(g.e)
            col.addView(Ui.tv(this, a[2].toString() + " " + MONTHS[a[1] - 1] + " – " + b[2] + " " + MONTHS[b[1] - 1], 12f, pal.muted))
            row.addView(col, LinearLayout.LayoutParams(0, Ui.WC, 1f))
            row.addView(Ui.tv(this, Math.round(m.prog(g) * 100).toString() + "%", 15f, pal.fg, true))
            root.addView(row, Ui.lp(Ui.MP, Ui.WC))
        }
        val open = Ui.btn(this, T("فتح في التطبيق", "Open in app"), PalGen.alpha(pal.fg, 28), pal.fg)
        open.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
        root.addView(open, Ui.lp(Ui.MP, Ui.WC, dp(14)))
        setContentView(root)
        Glass.apply(this, pal)
    }
}
